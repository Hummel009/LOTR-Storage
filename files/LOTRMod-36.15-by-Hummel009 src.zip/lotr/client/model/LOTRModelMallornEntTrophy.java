/*
 * Decompiled with CFR 0.148.
 */
package lotr.client.model;

public class LOTRModelMallornEntTrophy {
}

