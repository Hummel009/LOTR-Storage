/*
 * Decompiled with CFR 0.148.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiScreen
 */
package lotr.client.gui;

import java.util.List;
import net.minecraft.client.gui.GuiScreen;

public class LOTRGuiAchievementHoverEvent
extends GuiScreen {
    public void drawCreativeTabHoveringText(String s, int x, int y) {
        super.drawCreativeTabHoveringText(s, x, y);
    }

    public void func_146283_a(List text, int x, int y) {
        super.func_146283_a(text, x, y);
    }
}

