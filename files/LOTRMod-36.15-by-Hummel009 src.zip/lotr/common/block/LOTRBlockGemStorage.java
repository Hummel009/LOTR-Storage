/*
 * Decompiled with CFR 0.148.
 */
package lotr.common.block;

import lotr.common.block.LOTRBlockOreStorageBase;

public class LOTRBlockGemStorage
extends LOTRBlockOreStorageBase {
    public LOTRBlockGemStorage() {
        this.setOreStorageNames("topaz", "amethyst", "sapphire", "ruby", "amber", "diamond", "pearl", "opal", "coral", "emerald");
    }
}

