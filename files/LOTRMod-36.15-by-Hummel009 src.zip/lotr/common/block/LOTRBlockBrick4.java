/*
 * Decompiled with CFR 0.148.
 */
package lotr.common.block;

import lotr.common.block.LOTRBlockBrickBase;

public class LOTRBlockBrick4
extends LOTRBlockBrickBase {
    public LOTRBlockBrick4() {
        this.setBrickNames("tauredain", "tauredainMossy", "tauredainCracked", "tauredainGold", "tauredainObsidian", "dwarvenCracked", "blackGondorCarved", "nearHaradLapis", "highElvenSilver", "galadhrimSilver", "woodElvenSilver", "highElvenGold", "galadhrimGold", "woodElvenGold", "dwarvenObsidian", "chalk");
    }
}

