/*
 * Decompiled with CFR 0.148.
 */
package lotr.common.block;

import lotr.common.block.LOTRBlockBrickBase;

public class LOTRBlockBrick2
extends LOTRBlockBrickBase {
    public LOTRBlockBrick2() {
        this.setBrickNames("angmar", "angmarCracked", "redRock", "arnor", "arnorMossy", "arnorCracked", "arnorCarved", "uruk", "dolGuldur", "dolGuldurCracked", "mordorCarved", "blackGondor", "dwarvenCarved", "highElvenCarved", "woodElvenCarved", "galadhrimCarved");
    }
}

