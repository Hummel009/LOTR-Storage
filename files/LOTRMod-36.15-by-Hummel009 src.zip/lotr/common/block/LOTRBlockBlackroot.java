/*
 * Decompiled with CFR 0.148.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 */
package lotr.common.block;

import lotr.common.block.LOTRBlockFlower;
import net.minecraft.block.Block;

public class LOTRBlockBlackroot
extends LOTRBlockFlower {
    public LOTRBlockBlackroot() {
        float f = 0.125f;
        this.setFlowerBounds(f, 0.0f, f, 1.0f - f, 0.8f, 1.0f - f);
    }
}

