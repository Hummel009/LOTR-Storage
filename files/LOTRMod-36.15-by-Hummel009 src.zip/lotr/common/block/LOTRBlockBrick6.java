/*
 * Decompiled with CFR 0.148.
 */
package lotr.common.block;

import lotr.common.block.LOTRBlockBrickBase;

public class LOTRBlockBrick6
extends LOTRBlockBrickBase {
    public LOTRBlockBrick6() {
        this.setBrickNames("rhunGold", "rhunRed", "rhunRedCarved", "daleMossy", "daleCracked", "daleCarved", "umbar", "umbarCracked", "umbarCarved", "blackUmbarCarved", "angmarSnow", "dolGuldurMossy", "dolGuldurCarved", "morwaithCracked");
    }
}

