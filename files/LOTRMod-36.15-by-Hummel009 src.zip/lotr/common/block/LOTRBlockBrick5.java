/*
 * Decompiled with CFR 0.148.
 */
package lotr.common.block;

import lotr.common.block.LOTRBlockBrickBase;

public class LOTRBlockBrick5
extends LOTRBlockBrickBase {
    public LOTRBlockBrick5() {
        this.setBrickNames("mud", "dale", "dorwinion", "rohanCarved", "dorwinionMossy", "dorwinionCracked", "dorwinionCarved", "dorwinionFlowers", "gondorRustic", "gondorRusticMossy", "gondorRusticCracked", "rhun", "rhunCarved", "rhunMossy", "rhunCracked", "rhunFlowers");
    }
}

