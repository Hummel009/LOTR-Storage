/*
 * Decompiled with CFR 0.148.
 */
package lotr.common.block;

import lotr.common.block.LOTRBlockWoodBase;

public class LOTRBlockFruitWood
extends LOTRBlockWoodBase {
    public LOTRBlockFruitWood() {
        this.setWoodNames("apple", "pear", "cherry", "mango");
    }
}

