/*
 * Decompiled with CFR 0.148.
 */
package io.gitlab.dwarfyassassin.lotrucp.core.patches;

public class LOTRPatcher {
}

